

clear;
clc;
close all;


lambda=0.03;
ele_num=20;
pro_dim=ele_num;
Imat=eye(pro_dim,pro_dim);
sensor_pos=[0:(ele_num-1)]'*(0.45*lambda);
sig_angle_actual=0;
tar_steer_actual=exp(1j*2*pi*sensor_pos*sin(sig_angle_actual/180*pi)/lambda);
Mydiff=0.5;
seek_theta=[-90:Mydiff:90];
center_index=round((sig_angle_actual+90)/Mydiff)+1;
seek_num=length(seek_theta);
diff_sector=2;
main_left_ang=-40;
main_right_ang=40;
side_left_ang=-50;
side_right_ang=50;
y_lim_min=-40;
main_left_ang_index=round((main_left_ang+90)/Mydiff)+1;
main_right_ang_index=round((main_right_ang+90)/Mydiff)+1;
side_left_ang_index=round((side_left_ang+90)/Mydiff)+1;
side_right_ang_index=round((side_right_ang+90)/Mydiff)+1;



main_sector=[main_left_ang:diff_sector:main_right_ang];
side_sector=[[-90:diff_sector:side_left_ang] [side_right_ang:diff_sector:90]];

side_db=-25;
side_v=10^(side_db/10);

desired_pattern=zeros(1,seek_num);
desired_pattern(1:side_left_ang_index)=side_db;
desired_pattern(side_right_ang_index:seek_num)=side_db;
desired_pattern(side_left_ang_index+1:main_left_ang_index-1)=0/0;
desired_pattern(main_right_ang_index+1:side_right_ang_index-1)=0/0;

steer_main=zeros(ele_num,length(main_sector));
steer_side=zeros(ele_num,length(side_sector));

for reg_ang=1:length(main_sector)
    steer_main(:,reg_ang)=exp(1j*2*pi*sensor_pos*sin(main_sector(reg_ang)/180*pi)/lambda);
end

for reg_ang=1:length(side_sector)
    steer_side(:,reg_ang)=exp(1j*2*pi*sensor_pos*sin(side_sector(reg_ang)/180*pi)/lambda);
end

a_vec_all=exp(1j*2*pi*sensor_pos*sin(seek_theta/180*pi)/lambda);
resp=abs(tar_steer_actual'*a_vec_all);
pattern_last=20*log10(resp./max(resp));

initial_pattern=pattern_last;


tic
w_last=tar_steer_actual;
loop_num_main=372;
locad_max_min_diff=zeros(1,loop_num_main);
pattern_qui=initial_pattern;

for reg=1:loop_num_main
    reg
    last_pattern=pattern_qui;
    pattern_qui_reg=pattern_qui;
    index_all_max=find(pattern_qui_reg==max(pattern_qui_reg(:)));
    index_max_final=index_all_max(1);
    
    
    main_max_st=a_vec_all(:,index_max_final);
    main_max_angle=seek_theta(index_max_final);
    
    
    pattern_diff_abs_local=abs(desired_pattern(main_left_ang_index:main_right_ang_index)-...
        pattern_qui_reg(main_left_ang_index:main_right_ang_index));
    theta_local=seek_theta(main_left_ang_index:main_right_ang_index);
    
    index_diff_max=find(pattern_diff_abs_local==max(pattern_diff_abs_local(:)));
    jammer_angle_actual=theta_local(index_diff_max(1));
    
    
    jam_index=round((jammer_angle_actual+90)/Mydiff+1);
    jamm_steer=a_vec_all(:,jam_index);
    [ wopt_h] = WORDsinglepoint( w_last,jamm_steer,main_max_st,desired_pattern(jam_index));
    
    
    resp_smi_using_jn_ideal=abs(wopt_h'*a_vec_all);
    
    
    pattern_idea=20*log10(resp_smi_using_jn_ideal./max(resp_smi_using_jn_ideal));
    pattern_idea_local=pattern_idea(main_left_ang_index:main_right_ang_index);
    pattern_idea_local_max=max(pattern_idea_local);
    pattern_idea_local_min=min(pattern_idea_local);
    locad_max_min_diff(reg)=pattern_idea_local_max(1)-pattern_idea_local_min(1);
    
    pattern_qui=pattern_idea;
    w_last=wopt_h;
end
[x_loc,y_loc]=find(locad_max_min_diff==min(locad_max_min_diff));
pattern_idea=20*log10(resp_smi_using_jn_ideal./max(resp_smi_using_jn_ideal(center_index)));
pattern_qui=pattern_idea;

diva_max=zeros(1,300);

for reg=1:130
    reg
    jam_peak_index=[1];
    last_pattern=pattern_qui;
    pattern_qui_reg=pattern_qui;
    
    for reg2=2:length(pattern_qui_reg)-1
        if((pattern_qui_reg(reg2)>pattern_qui_reg(reg2+1))&&...
                (pattern_qui_reg(reg2)>pattern_qui_reg(reg2-1)))...
                ||((pattern_qui_reg(reg2)<pattern_qui_reg(reg2+1))&&...
                (pattern_qui_reg(reg2)<pattern_qui_reg(reg2-1))&&(reg2>=main_left_ang_index)...
                &&(reg2<=main_right_ang_index))
            jam_peak_index=[jam_peak_index reg2];
        end
    end
    
    pattern_diff_abs=abs(desired_pattern(jam_peak_index)-pattern_qui_reg(jam_peak_index));
    index_diff_max=find(pattern_diff_abs==max(pattern_diff_abs(:)));
    jammer_angle_actual=seek_theta(jam_peak_index(index_diff_max(1)));
    
    diva_max(reg)=pattern_diff_abs(index_diff_max(1));
    
    jam_index=round((jammer_angle_actual+90)/Mydiff+1);
    
    jamm_steer=a_vec_all(:,jam_index);
    
    diff_db=desired_pattern(jam_index);
    
    [ wopt_h] = WORDsinglepoint( w_last,jamm_steer,tar_steer_actual,desired_pattern(jam_index));
    
    resp_smi_using_jn_ideal=abs(wopt_h'*a_vec_all);
    pattern_idea=20*log10(resp_smi_using_jn_ideal./max(resp_smi_using_jn_ideal(center_index)));
    pattern_qui=pattern_idea;
    w_last=wopt_h;
end
res_word=wopt_h'*a_vec_all;
w_WORD=wopt_h;
w_WORD_abs=abs(w_WORD);
w_WORD_phase=angle(w_WORD);
w_WORD_abs_normal=w_WORD_abs/max(w_WORD_abs(:));

pattern_WORD=pattern_idea;

figure;
plot(seek_theta,last_pattern,'c-','LineWidth',2);hold on;
plot(seek_theta,pattern_idea,'r-','LineWidth',2);hold on;
plot(seek_theta,desired_pattern,'k--','LineWidth',1.5);hold off
grid on;
xlabel('\bf ANGLE(DEGREES)'); ylabel('\bf BEAMPATTERN(dB)');
line([sig_angle_actual,sig_angle_actual],[-70,10],'linewidth',1.3,'color','k','LineStyle','--');
line([jammer_angle_actual,jammer_angle_actual],[-70,10],'linewidth',1.3,'color','b','LineStyle','--');
ylim([-60 20]);
xlim([-90,90]);
set(gca,'fontsize',12);
legend('last iteration','current iteration','desired pattern');

