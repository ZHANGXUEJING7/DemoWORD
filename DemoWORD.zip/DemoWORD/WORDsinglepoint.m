function [ w_cur] = WORDsinglepoint(w_last,j_st,t_st,rhodb)

ele_num=length(w_last);
rou_p_cur=10^(rhodb/10);

P_j_par=j_st*j_st'/(j_st'*j_st);
P_j_bar=eye(ele_num)-P_j_par;


w_0_bar=P_j_bar*w_last;
w_0_par=P_j_par*w_last;

R1=[w_0_bar'*j_st;w_0_par'*j_st];
R2=[w_0_bar'*t_st;w_0_par'*t_st];



Q=R1*R1'-rou_p_cur*R2*R2';
d=sqrt(real(Q(1,2))^2-real(Q(1,1))*real(Q(2,2)));
beta_a=(-real(Q(1,2))+d)/real(Q(2,2));
beta_b=(-real(Q(1,2))-d)/real(Q(2,2));

w_cura=w_0_bar+beta_a*w_0_par;
w_curb=w_0_bar+beta_b*w_0_par;

P_w0_bot=eye(ele_num)-w_last*w_last'/(w_last'*w_last);

word_real_cost1=norm(P_w0_bot'*w_cura/norm(w_cura));
word_real_cost2=norm(P_w0_bot'*w_curb/norm(w_curb));


if(word_real_cost1<word_real_cost2)
    w_cur=w_cura;
else
    w_cur=w_curb;
end
end

